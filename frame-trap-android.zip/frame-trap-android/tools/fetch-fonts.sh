#!/bin/sh
# Downloads the game's five typefaces (and their licence texts) into the app, so the APK carries them and never needs
# the network. All five are free under the SIL Open Font License. The GitHub build runs this for you.
# If a download fails the game still works; that text simply falls back to the phone's own font.
cd "$(dirname "$0")/.." || exit 1
MAIN="https://raw.githubusercontent.com/google/fonts/main/ofl"
SPARE="https://cdn.jsdelivr.net/fontsource/fonts"
OUT="app/src/main/assets/fonts"
mkdir -p "$OUT/licenses"
fail=0
fetch() { # fetch <url> <save as>
  curl -fsSL --retry 2 --max-time 60 -o "$2.part" "$1" && [ -s "$2.part" ] && mv "$2.part" "$2"
}
font() { # font <google folder> <file> <spare path>
  if [ -s "$OUT/$2" ]; then return 0; fi
  if fetch "$MAIN/$1/$2" "$OUT/$2" || fetch "$SPARE/$3" "$OUT/$2"; then echo "ok     $2"
  else rm -f "$OUT/$2.part"; echo "MISSED $2"; fail=1; fi
}
font anton               Anton-Regular.ttf                "anton@latest/latin-400-normal.ttf"
font pressstart2p        PressStart2P-Regular.ttf         "press-start-2p@latest/latin-400-normal.ttf"
font barlowsemicondensed BarlowSemiCondensed-Regular.ttf  "barlow-semi-condensed@latest/latin-400-normal.ttf"
font barlowsemicondensed BarlowSemiCondensed-SemiBold.ttf "barlow-semi-condensed@latest/latin-600-normal.ttf"
font ibmplexmono         IBMPlexMono-Medium.ttf           "ibm-plex-mono@latest/latin-500-normal.ttf"
for f in anton pressstart2p barlowsemicondensed ibmplexmono; do
  fetch "$MAIN/$f/OFL.txt" "$OUT/licenses/$f-OFL.txt" || rm -f "$OUT/licenses/$f-OFL.txt.part"
done
ls -l "$OUT"
exit $fail
