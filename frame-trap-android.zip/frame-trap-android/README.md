# Frame Trap for Android

This is the Android app version of Frame Trap. GitHub builds the APK for you; nothing needs installing on your own
computer.

The app is one full-screen, landscape screen that runs the game from files packed inside the APK. It has no ads, no
accounts, and it never goes online.

## Get the APK (about ten minutes, once)

1. Sign in at github.com and create a new repository (the **+** at the top, then **New repository**). Any name works,
   for example `frame-trap`. Private is fine and keeps your game's code to yourself.
2. In the new repository choose **uploading an existing file** (or **Add file > Upload files**), pick
   `frame-trap-android.zip` exactly as you received it (do not unzip it), and press **Commit changes**.
3. Open the **Actions** tab and choose **set up a workflow yourself**. Delete whatever is in the editor, paste in the
   whole of `build-apk.yml`, and press **Commit changes**.
4. The build starts on its own. Watch it on the **Actions** tab; it takes roughly three to five minutes. A green tick
   means it worked.
5. Go to the repository's front page and open **Releases** (on a phone it is further down the page). Download
   `FrameTrap.apk` from the newest one.

If you are on a computer and prefer it, you can instead unzip the project and drag all of its contents into the
repository. The build handles both layouts. The `.github` folder is hidden on some computers and can be left behind by
a drag and drop, which is why step 3 pastes the build recipe in by hand.

## Install it on a phone

Open `FrameTrap.apk` on the phone. Android will ask once for permission to install apps from your browser or file
manager; allow it, then press **Install**. Play Protect may show a notice because the app did not come from the Play
Store; choose **Install anyway**.

Needs Android 8.0 or newer.

## Update the game later

Upload the new `frame-trap-android.zip` to the same repository. GitHub rebuilds on its own and a new release appears.
If there is more than one zip in the repository, the one uploaded last is used.

Every build is signed with the same test key (`app/debug.keystore`), so a new APK installs straight over the old one
and saved settings and high scores are kept.

If you only changed the game itself, the single file that matters is `app/src/main/assets/index.html`.

## If the build fails

Open the failed run on the **Actions** tab, click the step with the red cross, and copy the last forty or so lines of
its log. That text says what went wrong.

## What is in here

| Path | What it is |
| --- | --- |
| `app/src/main/assets/index.html` | The whole game: one page, phone layout, touch controls |
| `app/src/main/assets/fonts/` | The game's typefaces; the build downloads them (`tools/fetch-fonts.sh`) |
| `app/src/main/java/.../MainActivity.java` | The app shell: full screen, landscape, back button, pause when you leave |
| `app/src/main/AndroidManifest.xml` | App name, icon, orientation |
| `app/src/main/res/` | Icon, colours, theme |
| `app/build.gradle` | App id, version number, Android versions supported |
| `.github/workflows/build-apk.yml` | The recipe GitHub follows to build the APK |

The project also opens in Android Studio if you ever want to build on your own computer.

## Before a Play Store release

None of this is needed for an APK you share directly. It is the list for later.

- **App id.** `com.oneshinoah.frametrap` in `app/build.gradle` is permanent once the first upload is made. Change it
  before then if you want a different one (also rename the folder under `java/` and the `package` line in
  `MainActivity.java`).
- **Your own signing key.** The Play Store will not accept the test key. Create a private upload key, keep it out of
  the repository, and build a release bundle (`.aab`) with `gradle bundleRelease`.
- **Version numbers.** Raise `versionCode` by one for every upload.
- **Target Android version.** Google raises the minimum `targetSdk` each year; check the current requirement and
  raise `compileSdk` and `targetSdk` to match.
- **Names.** Raz's ultimate is called "Ninja Gaiden", which is the name of an existing game series; rename it before
  publishing. It is worth checking "Frame Trap" and the fighter names against the store as well.
- **Fonts.** Anton, Press Start 2P, Barlow Semi Condensed and IBM Plex Mono are free under the SIL Open Font
  License; their licence texts are packed in `assets/fonts/licenses`.
- **Internet permission.** The manifest declares it only as a safety net for the in-app page loader. The game never
  uses the network, so try removing that line and confirm the game still starts; then the store listing can say the
  app needs no permissions.
- **Store listing.** A 512 x 512 icon, a feature graphic, screenshots, a privacy policy page, and the content rating
  questionnaire (the game has cartoon fighting).
